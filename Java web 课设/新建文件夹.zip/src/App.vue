<template>
  <div id="app">
    <router-view ></router-view>
    <!-- <dept-view></dept-view> -->
    <!-- <router-view name="path"></router-view> -->
  </div>
</template>

<script>
// import DeptView from './views/element/DeptView.vue'
export default {
  components: {  },

}
</script>
<style>

</style>
